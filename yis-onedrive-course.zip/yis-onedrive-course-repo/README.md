# YIS OneDrive Certification Course

**Yenepoya International School — Al Khobar, Saudi Arabia**  
*Darb Al-Mostaqbal Education Company*

A self-paced Microsoft OneDrive certification course for YIS teachers.

## Modules covered
1. Uploading & organising files
2. Sharing & permissions  
3. Syncing to desktop
4. Co-authoring in real time
5. Version history & recovery
6. Teams + OneDrive integration

## Usage
Open `index.html` in any browser — no internet required after download.  
Or visit the hosted link shared by the ICT Department.

*Built by YIS ICT Department, 2025*
